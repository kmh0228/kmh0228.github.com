CREATE FUNCTION fun_get_zwgf_weekend(dt in DATE)
RETURN NUMBER
IS
 zwgf NUMBER;
 dtMinute NUMBER(6);
 dtXingQi Varchar2(20);
BEGIN
dtMinute:= to_number(to_char(dt,'hh24MI'));
dtXingQi := SUBSTR(to_char(dt,'day','NLS_DATE_LANGUAGE=''SIMPLIFIED CHINESE'''),-1) ;
if dtXingQi ='六' OR dtXingQi='日' THEN
      if dtMinute >= 700 AND dtMinute < 900  THEN zwgf:=1;
		  elsif dtMinute >= 900 AND dtMinute < 1100  THEN zwgf:=1;
		  elsif dtMinute >= 1500 AND dtMinute < 1700  THEN zwgf:=4;
		  elsif dtMinute >= 1700 AND dtMinute < 1900  THEN zwgf:=4;
		  else return NULL;
	  end if;
    ELSE
        if dtMinute >= 700 AND dtMinute < 900  THEN zwgf:=1;
		elsif dtMinute >= 1700 AND dtMinute < 1900 THEN zwgf:=4;
		else return NULL;
        end if;
    end if;
	return zwgf;
END fun_get_zwgf_weekend;
/
