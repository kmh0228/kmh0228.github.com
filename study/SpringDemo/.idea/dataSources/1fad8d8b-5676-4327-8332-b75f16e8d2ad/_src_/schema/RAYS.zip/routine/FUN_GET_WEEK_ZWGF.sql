CREATE FUNCTION fun_get_week_zwgf(dt in DATE)
RETURN VARCHAR2
IS
 strRst Varchar2(20);
 dtXingQi Varchar2(20);
 zwgf Varchar2(20);
 dtMinute NUMBER(6);
BEGIN
    dtXingQi := '周' || SUBSTR(to_char(dt,'day','NLS_DATE_LANGUAGE=''SIMPLIFIED CHINESE'''),-1) ;
    dtMinute := to_number(to_char(dt,'hh24MI'));
	   CASE
		WHEN dtMinute >= 700 AND dtMinute < 900  THEN zwgf:='早高峰';
		WHEN dtMinute >= 900 AND dtMinute < 1100  THEN zwgf:='上低峰';
		WHEN dtMinute >= 1430 AND dtMinute < 1700 THEN zwgf:='下低峰';
		WHEN dtMinute >= 1700 AND dtMinute < 1900 THEN zwgf:='晚高峰';
		WHEN dtMinute >= 1900 AND dtMinute < 2200 THEN zwgf:='晚二次';
		ELSE RETURN NULL;
	  END CASE;
	strRst:= dtXingQi || zwgf;
	return strRst;
END fun_get_week_zwgf;
/
