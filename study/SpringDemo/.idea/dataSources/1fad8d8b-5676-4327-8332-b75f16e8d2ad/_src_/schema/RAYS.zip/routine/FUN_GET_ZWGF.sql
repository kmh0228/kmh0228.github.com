CREATE FUNCTION fun_get_zwgf(dt in DATE)
RETURN NUMBER
IS
 zwgf NUMBER;
 dtMinute NUMBER(6);
BEGIN
    dtMinute := to_number(to_char(dt,'hh24MI'));
	   CASE 
		WHEN dtMinute >= 700 AND dtMinute < 900  THEN zwgf:=1;
		WHEN dtMinute >= 900 AND dtMinute < 1100  THEN zwgf:=2;
		WHEN dtMinute >= 1430 AND dtMinute < 1700 THEN zwgf:=3;
		WHEN dtMinute >= 1700 AND dtMinute < 1900 THEN zwgf:=4;
		WHEN dtMinute >= 1900 AND dtMinute < 2200 THEN zwgf:=5;
		ELSE RETURN NULL;
	  END CASE;
	return zwgf;
END fun_get_zwgf;
/
