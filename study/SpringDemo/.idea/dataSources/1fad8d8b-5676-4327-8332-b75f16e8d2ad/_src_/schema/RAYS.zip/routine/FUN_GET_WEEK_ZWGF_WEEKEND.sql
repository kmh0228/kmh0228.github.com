CREATE FUNCTION fun_get_week_zwgf_weekend(dt in DATE)
RETURN VARCHAR2
IS
  strRst Varchar2(40);
  zwgf Varchar2(40);
 dtMinute NUMBER(6);
 dtXingQi Varchar2(20);
BEGIN
    dtMinute:= to_number(to_char(dt,'hh24MI'));
    dtXingQi := SUBSTR(to_char(dt,'day','NLS_DATE_LANGUAGE=''SIMPLIFIED CHINESE'''),-1) ;
    if dtXingQi ='六' OR dtXingQi='日' THEN
      if dtMinute >= 700 AND dtMinute < 900  THEN zwgf:='早高峰(7-9)';
		    elsif dtMinute >= 900 AND dtMinute < 1100  THEN zwgf:='早高峰(9-11)';
		    elsif dtMinute >= 1500 AND dtMinute < 1700  THEN zwgf:='晚高峰(15-17)';
		    elsif dtMinute >= 1700 AND dtMinute < 1900  THEN zwgf:='晚高峰(17-19)';
		    else return NULL;
	    end if;
    ELSE
      if dtMinute >= 700 AND dtMinute < 900  THEN zwgf:='早高峰';
		    elsif dtMinute >= 1700 AND dtMinute < 1900 THEN zwgf:='晚高峰';
		    else return NULL;
      end if;
    end if;
    strRst:='周' || dtXingQi || zwgf;
	return strRst;
END fun_get_week_zwgf_weekend;
/
